import { useState } from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import ScreeningEngine from "./pages/ScreeningEngine";
import SanctionsIntelligence from "./pages/SanctionsIntelligence";
import CountryRisk from "./pages/CountryRisk";
import AICopilot from "./pages/AICopilot";
import CaseManagement from "./pages/CaseManagement";

export type Page = 'dashboard' | 'screening' | 'sanctions' | 'country' | 'ai' | 'cases';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} />;
      case 'screening':
        return <ScreeningEngine />;
      case 'sanctions':
        return <SanctionsIntelligence />;
      case 'country':
        return <CountryRisk />;
      case 'ai':
        return <AICopilot />;
      case 'cases':
        return <CaseManagement />;
      default:
        return <Dashboard onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="flex-1 overflow-auto">
        {renderPage()}
      </main>
    </div>
  );
}