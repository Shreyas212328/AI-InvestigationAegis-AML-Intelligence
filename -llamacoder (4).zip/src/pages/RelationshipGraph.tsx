import { motion } from "framer-motion";
import { Users, Link2, Building2 } from "lucide-react";
import { entities, connections } from "../data/mockData";

export default function RelationshipGraph() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold text-white">Entity Relationship Graph</h1>
        <p className="text-slate-400 mt-1">Neo4j-powered beneficial ownership mapping</p>
      </motion.div>

      {/* Graph Visualization */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-slate-900 border border-slate-800 rounded-xl p-6 h-96 relative overflow-hidden"
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative w-full h-full max-w-2xl">
            {/* Connection lines */}
            <svg className="absolute inset-0 w-full h-full">
              {connections.map((conn, i) => {
                const from = entities.find(e => e.id === conn.from);
                const to = entities.find(e => e.id === conn.to);
                if (!from || !to) return null;
                return (
                  <motion.line
                    key={i}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 0.5 }}
                    transition={{ delay: 0.5 + i * 0.1 }}
                    x1={`${from.x}%`}
                    y1={`${from.y}%`}
                    x2={`${to.x}%`}
                    y2={`${to.y}%`}
                    stroke="#3b82f6"
                    strokeWidth="2"
                    strokeDasharray="5,5"
                  />
                );
              })}
            </svg>

            {/* Entity nodes */}
            {entities.map((entity, index) => (
              <motion.div
                key={entity.id}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.3 + index * 0.1, type: "spring" }}
                className={`absolute w-16 h-16 rounded-full flex items-center justify-center cursor-pointer transform -translate-x-1/2 -translate-y-1/2 ${
                  entity.type === 'company' 
                    ? "bg-blue-500/20 border-2 border-blue-500" 
                    : "bg-purple-500/20 border-2 border-purple-500"
                }`}
                style={{ left: `${entity.x}%`, top: `${entity.y}%` }}
                whileHover={{ scale: 1.2 }}
              >
                {entity.type === 'company' ? (
                  <Building2 className="text-blue-400" size={24} />
                ) : (
                  <Users className="text-purple-400" size={24} />
                )}
              </motion.div>
            ))}

            {/* Labels */}
            {entities.map((entity, index) => (
              <motion.div
                key={`label-${entity.id}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                className="absolute text-xs text-white transform -translate-x-1/2 mt-10"
                style={{ left: `${entity.x}%`, top: `${entity.y}%` }}
              >
                {entity.name}
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Entity Details */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {entities.slice(0, 3).map((entity, index) => (
          <motion.div
            key={entity.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + index * 0.1 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-4"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                entity.type === 'company' ? "bg-blue-500/20" : "bg-purple-500/20"
              }`}>
                {entity.type === 'company' ? (
                  <Building2 className="text-blue-400" size={20} />
                ) : (
                  <Users className="text-purple-400" size={20} />
                )}
              </div>
              <div>
                <p className="text-white font-medium">{entity.name}</p>
                <p className="text-slate-400 text-sm capitalize">{entity.type}</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className={`text-xs px-2 py-1 rounded ${
                entity.risk === 'Critical' ? "bg-red-500/20 text-red-400" :
                entity.risk === 'High' ? "bg-orange-500/20 text-orange-400" :
                "bg-yellow-500/20 text-yellow-400"
              }`}>
                {entity.risk} Risk
              </span>
              <button className="text-blue-400 text-sm hover:text-blue-300">
                View Details
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}