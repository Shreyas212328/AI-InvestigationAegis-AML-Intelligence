import { motion } from "framer-motion";
import { useState } from "react";
import { Search, AlertTriangle, User, Building2, Globe } from "lucide-react";
import { screeningResults, sanctions } from "../data/mockData";

export default function NameScreening() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState(screeningResults);

  const handleSearch = () => {
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      setResults(screeningResults);
    }, 1500);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold text-white">Name Screening Engine</h1>
        <p className="text-slate-400 mt-1">Screen individuals and entities against global watchlists</p>
      </motion.div>

      {/* Search Panel */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-slate-900 border border-slate-800 rounded-xl p-6"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm text-slate-400 mb-2">Entity Name</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Enter name to screen..."
                className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-2">Entity Type</label>
            <select className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500">
              <option>Individual</option>
              <option>Company</option>
              <option>Vessel</option>
            </select>
          </div>
        </div>
        
        <div className="flex items-center gap-4 mt-4">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSearch}
            disabled={isSearching}
            className="px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors disabled:opacity-50"
          >
            {isSearching ? "Screening..." : "Screen Entity"}
          </motion.button>
          <button className="px-6 py-3 bg-slate-800 text-slate-300 rounded-lg font-medium hover:bg-slate-700 transition-colors">
            Advanced Options
          </button>
        </div>
      </motion.div>

      {/* Results */}
      {results.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          <h2 className="text-xl font-semibold text-white">Screening Results</h2>
          
          {results.map((result, index) => (
            <motion.div
              key={result.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className={`bg-slate-900 border rounded-xl p-6 ${
                result.risk === "Critical" ? "border-red-500/50" : 
                result.risk === "High" ? "border-orange-500/50" : "border-slate-800"
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-lg ${
                    result.risk === "Critical" ? "bg-red-500/20" : "bg-orange-500/20"
                  }`}>
                    {result.risk === "Critical" ? (
                      <AlertTriangle className="text-red-400" size={24} />
                    ) : (
                      <User className="text-orange-400" size={24} />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="text-white font-semibold">{result.inputName}</h3>
                      <span className={`text-xs px-2 py-1 rounded ${
                        result.risk === "Critical" ? "bg-red-500/20 text-red-300" : 
                        "bg-orange-500/20 text-orange-300"
                      }`}>
                        {result.risk}
                      </span>
                    </div>
                    <p className="text-slate-400 text-sm mt-1">
                      Matched: <span className="text-white">{result.matchName}</span>
                    </p>
                    <p className="text-slate-500 text-sm mt-1">
                      Source: {result.source} • Match Score: {result.matchScore}%
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-slate-400 text-sm">{result.status}</p>
                  <button className="mt-2 px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg text-sm hover:bg-blue-500/30 transition-colors">
                    Investigate
                  </button>
                </div>
              </div>
              
              {/* Match Score Bar */}
              <div className="mt-4">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>Match Confidence</span>
                  <span>{result.matchScore}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${result.matchScore}%` }}
                    transition={{ delay: 0.5 + index * 0.1, duration: 0.5 }}
                    className={`h-full rounded-full ${
                      result.matchScore >= 90 ? "bg-red-500" :
                      result.matchScore >= 70 ? "bg-orange-500" : "bg-yellow-500"
                    }`}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Watchlist Sources */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-slate-900 border border-slate-800 rounded-xl p-6"
      >
        <h3 className="text-white font-semibold mb-4">Active Watchlist Sources</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {["OFAC SDN", "EU Sanctions", "UN Sanctions", "UK Sanctions", "PEP Database", "Adverse Media", "State Sponsors", "DPL List"].map((source, index) => (
            <motion.div
              key={source}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 + index * 0.05 }}
              className="flex items-center gap-2 p-3 bg-slate-800/50 rounded-lg"
            >
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span className="text-slate-300 text-sm">{source}</span>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}