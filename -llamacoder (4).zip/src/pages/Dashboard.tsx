import { motion } from "framer-motion";
import { Shield, ArrowRight, AlertTriangle, Globe } from "lucide-react";
import KPICard from "../components/KPICard";
import RiskGauge from "../components/RiskGauge";
import WorldMap, { CountryData } from "../components/WorldMap";
import { kpis, alerts, countries, countryData } from "../data/mockData";
import { Page } from "../App";

interface DashboardProps {
  onNavigate: (page: Page) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const handleCountryClick = (country: CountryData) => {
    onNavigate('country');
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">AML Intelligence Dashboard</h1>
            <p className="text-slate-400 mt-1">Real-time financial crime monitoring & sanctions intelligence</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('screening')}
            className="px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center gap-2"
          >
            <Shield size={18} />
            Launch Screening Engine
          </motion.button>
        </div>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPICard
          title="Critical Alerts"
          value={kpis.criticalAlerts}
          change={12}
          icon="alerts"
          color="red"
          index={0}
        />
        <KPICard
          title="High-Risk Customers"
          value={kpis.highRiskCustomers}
          change={-5}
          icon="customers"
          color="orange"
          index={1}
        />
        <KPICard
          title="Pending Reviews"
          value={kpis.pendingReviews}
          change={8}
          icon="shield"
          color="blue"
          index={2}
        />
        <KPICard
          title="Avg Resolution"
          value={kpis.avgResolutionTime}
          change={-15}
          icon="time"
          color="green"
          index={3}
        />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* World Map */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Global Risk Heat Map</h3>
            <Globe size={18} className="text-slate-500" />
          </div>
          <WorldMap onCountryClick={handleCountryClick} />
        </motion.div>

        {/* Risk Gauges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-slate-900 border border-slate-800 rounded-xl p-4"
        >
          <h3 className="text-white font-semibold mb-4">Risk Overview</h3>
          <div className="grid grid-cols-2 gap-4">
            <RiskGauge score={78} label="Sanctions" size="sm" />
            <RiskGauge score={45} label="PEP" size="sm" />
            <RiskGauge score={62} label="Adverse Media" size="sm" />
            <RiskGauge score={55} label="Country" size="sm" />
          </div>
        </motion.div>
      </div>

      {/* Alerts List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-6 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden"
      >
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-white font-semibold">Recent Alerts</h3>
          <span className="text-xs text-slate-500">Last 24 hours</span>
        </div>
        <div className="divide-y divide-slate-800">
          {alerts.slice(0, 5).map((alert) => (
            <motion.div
              key={alert.id}
              whileHover={{ backgroundColor: "rgba(30, 41, 59, 0.5)" }}
              className="p-4 flex items-center justify-between cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${
                  alert.severity === "Critical" 
                    ? "bg-red-500/20" 
                    : alert.severity === "High" 
                    ? "bg-orange-500/20" 
                    : "bg-yellow-500/20"
                }`}>
                  <AlertTriangle size={16} className={
                    alert.severity === "Critical" 
                      ? "text-red-400" 
                      : alert.severity === "High" 
                      ? "text-orange-400" 
                      : "text-yellow-400"
                  } />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">{alert.title}</p>
                  <p className="text-slate-500 text-xs">{alert.entity} • {alert.country}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  alert.severity === "Critical" 
                    ? "bg-red-500/20 text-red-400" 
                    : alert.severity === "High" 
                    ? "bg-orange-500/20 text-orange-400" 
                    : "bg-yellow-500/20 text-yellow-400"
                }`}>
                  {alert.severity}
                </span>
                <span className="text-slate-500 text-xs">{alert.timestamp}</span>
              </div>
            </motion.div>
          ))}
        </div>
        <div className="p-4 border-t border-slate-800">
          <button className="w-full text-blue-400 text-sm hover:text-blue-300 flex items-center justify-center gap-1">
            View All Alerts <ArrowRight size={14} />
          </button>
        </div>
      </motion.div>
    </div>
  );
}