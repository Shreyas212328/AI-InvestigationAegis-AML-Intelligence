import { motion } from "framer-motion";
import { Globe, AlertTriangle, TrendingUp } from "lucide-react";

const countries = [
  { name: "Iran", risk: 95, category: "Sanctions", flag: "🇮🇷" },
  { name: "North Korea", risk: 98, category: "Sanctions", flag: "🇰🇵" },
  { name: "Russia", risk: 85, category: "Sanctions", flag: "🇷🇺" },
  { name: "Syria", risk: 92, category: "Sanctions", flag: "🇸🇾" },
  { name: "Venezuela", risk: 72, category: "High Risk", flag: "🇻🇪" },
  { name: "Myanmar", risk: 68, category: "High Risk", flag: "🇲🇲" },
  { name: "Afghanistan", risk: 75, category: "High Risk", flag: "🇦🇫" },
  { name: "Yemen", risk: 70, category: "High Risk", flag: "🇾🇪" },
];

export default function RiskHeatmap() {
  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-1">Global Risk Heatmap</h1>
        <p className="text-slate-400">Country risk assessment and geographic analysis</p>
      </motion.div>

      {/* Map Placeholder */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6"
      >
        <div className="h-80 bg-slate-800 rounded-lg flex items-center justify-center border border-slate-700">
          <div className="text-center">
            <Globe className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">Interactive world map visualization</p>
            <p className="text-sm text-slate-500 mt-2">Powered by geographic risk data</p>
          </div>
        </div>
      </motion.div>

      {/* Country Risk Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-slate-900 rounded-xl border border-slate-800 p-6"
      >
        <h2 className="text-lg font-semibold text-white mb-4">High-Risk Jurisdictions</h2>
        <div className="space-y-3">
          {countries.map((country, index) => (
            <motion.div
              key={country.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * index }}
              className="flex items-center gap-4 p-4 bg-slate-800/50 rounded-lg border border-slate-700"
            >
              <span className="text-2xl">{country.flag}</span>
              <div className="flex-1">
                <p className="font-medium text-white">{country.name}</p>
                <p className="text-sm text-slate-400">{country.category}</p>
              </div>
              <div className="flex-1">
                <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${country.risk}%` }}
                    transition={{ delay: 0.3, duration: 0.8 }}
                    className={`h-full rounded-full ${
                      country.risk >= 90 ? 'bg-red-500' :
                      country.risk >= 70 ? 'bg-amber-500' : 'bg-yellow-500'
                    }`}
                  />
                </div>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold text-white">{country.risk}</p>
                <p className="text-xs text-slate-400">Risk Score</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}