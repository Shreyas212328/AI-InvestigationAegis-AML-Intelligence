import { useState } from "react";
import { motion } from "framer-motion";
import { Globe, AlertTriangle, Shield, TrendingUp, Users, DollarSign } from "lucide-react";
import RiskGauge from "../components/RiskGauge";
import WorldMap, { CountryData } from "../components/WorldMap";
import { countryData, countryRiskActivities } from "../data/mockData";

export default function CountryRisk() {
  const [selectedCountry, setSelectedCountry] = useState<CountryData | null>(countryData[0]);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCountries = countryData.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-1">Country Risk Intelligence</h1>
        <p className="text-slate-400">FATF status, sanctions exposure, and jurisdictional risk analysis</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Country List */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden"
        >
          <div className="p-4 border-b border-slate-800">
            <div className="relative">
              <input
                type="text"
                placeholder="Search countries..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
              <Globe size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500" />
            </div>
          </div>
          <div className="max-h-[500px] overflow-y-auto">
            {filteredCountries.map((country) => (
              <motion.button
                key={country.code}
                whileHover={{ backgroundColor: "rgba(30, 41, 59, 0.5)" }}
                onClick={() => setSelectedCountry(country)}
                className={`w-full p-4 flex items-center justify-between border-b border-slate-800 transition-colors ${
                  selectedCountry?.code === country.code ? "bg-blue-500/10" : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${
                    country.risk >= 80 ? "bg-red-500" : 
                    country.risk >= 60 ? "bg-orange-500" : 
                    country.risk >= 40 ? "bg-yellow-500" : "bg-green-500"
                  }`} />
                  <span className="text-white font-medium">{country.name}</span>
                </div>
                <span className={`text-sm font-bold ${
                  country.risk >= 80 ? "text-red-400" : 
                  country.risk >= 60 ? "text-orange-400" : 
                  country.risk >= 40 ? "text-yellow-400" : "text-green-400"
                }`}>
                  {country.risk}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Country Details */}
        {selectedCountry && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2 space-y-6"
          >
            {/* Header */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-white">{selectedCountry.name}</h2>
                  <p className="text-slate-400">{selectedCountry.fatfStatus}</p>
                </div>
                <div className="flex gap-4">
                  <RiskGauge score={selectedCountry.risk} label="Overall Risk" size="md" />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="bg-slate-800/50 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield size={16} className="text-blue-400" />
                    <span className="text-slate-400 text-sm">Sanctions Status</span>
                  </div>
                  <p className="text-white font-medium">{selectedCountry.sanctionsStatus}</p>
                </div>
                <div className="bg-slate-800/50 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign size={16} className="text-green-400" />
                    <span className="text-slate-400 text-sm">Transaction Risk</span>
                  </div>
                  <p className="text-white font-medium">{selectedCountry.transactionRisk}</p>
                </div>
                <div className="bg-slate-800/50 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp size={16} className="text-orange-400" />
                    <span className="text-slate-400 text-sm">Trade Risk</span>
                  </div>
                  <p className="text-white font-medium">{selectedCountry.tradeRisk}</p>
                </div>
              </div>
            </div>

            {/* Key Activities */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <AlertTriangle size={18} className="text-orange-400" />
                Key Risk Activities
              </h3>
              <div className="flex flex-wrap gap-2">
                {selectedCountry.keyActivities.map((activity, i) => (
                  <span key={i} className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-sm">
                    {activity}
                  </span>
                ))}
              </div>
            </div>

            {/* Typologies */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <Users size={18} className="text-purple-400" />
                Money Laundering Typologies
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {selectedCountry.typologies.map((typology, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                    {typology}
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <h3 className="text-white font-semibold mb-4">Compliance Recommendations</h3>
              <ul className="space-y-2">
                {selectedCountry.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2 text-slate-300">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400 mt-2" />
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}