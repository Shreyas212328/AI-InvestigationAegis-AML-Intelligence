import { motion } from "framer-motion";
import { FileText, Clock, User, AlertTriangle, CheckCircle, XCircle } from "lucide-react";

const cases = [
  {
    id: "CASE-2024-001",
    title: "Global Trading Corp - Sanctions Evasion",
    status: "open",
    priority: "critical",
    assignee: "John Smith",
    created: "2024-01-15",
    lastUpdated: "2 hours ago"
  },
  {
    id: "CASE-2024-002",
    title: "Pacific Holdings - PEP Review",
    status: "in_review",
    priority: "high",
    assignee: "Sarah Chen",
    created: "2024-01-14",
    lastUpdated: "5 hours ago"
  },
  {
    id: "CASE-2024-003",
    title: "Nordic Investments - Suspicious Activity",
    status: "pending",
    priority: "medium",
    assignee: "Mike Johnson",
    created: "2024-01-13",
    lastUpdated: "1 day ago"
  },
  {
    id: "CASE-2024-004",
    title: "ABC Trading Ltd - Transaction Monitoring",
    status: "closed",
    priority: "low",
    assignee: "Emily Davis",
    created: "2024-01-10",
    lastUpdated: "3 days ago"
  }
];

const statusColors: Record<string, string> = {
  open: "bg-red-500/20 text-red-400",
  in_review: "bg-blue-500/20 text-blue-400",
  pending: "bg-yellow-500/20 text-yellow-400",
  closed: "bg-green-500/20 text-green-400"
};

const priorityColors: Record<string, string> = {
  critical: "bg-red-500/20 text-red-400 border-red-500/30",
  high: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  low: "bg-slate-500/20 text-slate-400 border-slate-500/30"
};

export default function CaseManagement() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-white">Case Management</h1>
          <p className="text-slate-400 mt-1">Track and manage AML investigations</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
        >
          Create New Case
        </motion.button>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: "Open Cases", value: 23, icon: AlertTriangle, color: "red" },
          { label: "In Review", value: 12, icon: Clock, color: "blue" },
          { label: "Pending", value: 8, icon: FileText, color: "yellow" },
          { label: "Closed This Month", value: 47, icon: CheckCircle, color: "green" }
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-4"
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                stat.color === "red" ? "bg-red-500/20" :
                stat.color === "blue" ? "bg-blue-500/20" :
                stat.color === "yellow" ? "bg-yellow-500/20" : "bg-green-500/20"
              }`}>
                <stat.icon className={`w-5 h-5 ${
                  stat.color === "red" ? "text-red-400" :
                  stat.color === "blue" ? "text-blue-400" :
                  stat.color === "yellow" ? "text-yellow-400" : "text-green-400"
                }`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{stat.value}</p>
                <p className="text-sm text-slate-400">{stat.label}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Cases List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden"
      >
        <div className="p-4 border-b border-slate-800">
          <h2 className="text-white font-semibold">Active Cases</h2>
        </div>
        <div className="divide-y divide-slate-800">
          {cases.map((c, index) => (
            <motion.div
              key={c.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + index * 0.05 }}
              className="p-4 hover:bg-slate-800/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    c.status === "open" ? "bg-red-500/20" :
                    c.status === "in_review" ? "bg-blue-500/20" :
                    c.status === "pending" ? "bg-yellow-500/20" : "bg-green-500/20"
                  }`}>
                    <FileText className={`w-5 h-5 ${
                      c.status === "open" ? "text-red-400" :
                      c.status === "in_review" ? "text-blue-400" :
                      c.status === "pending" ? "text-yellow-400" : "text-green-400"
                    }`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-500 text-sm font-mono">{c.id}</span>
                      <span className={`text-xs px-2 py-0.5 rounded ${statusColors[c.status]}`}>
                        {c.status.replace('_', ' ').toUpperCase()}
                      </span>
                      <span className={`text-xs px-2 py-0.5 rounded border ${priorityColors[c.priority]}`}>
                        {c.priority.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-white font-medium mt-1">{c.title}</p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <User size={12} />
                        {c.assignee}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={12} />
                        {c.lastUpdated}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm transition-colors">
                    View
                  </button>
                  <button className="px-3 py-1.5 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 rounded-lg text-sm transition-colors">
                    Edit
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}