import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, AlertTriangle, Shield, User, Globe, Newspaper, Link2, CheckCircle, ChevronDown, Filter } from "lucide-react";
import RiskGauge from "../components/RiskGauge";
import IntelligenceCard from "../components/IntelligenceCard";
import { dataSources } from "../data/mockData";

interface ScreeningResult {
  submittedName: string;
  normalizedName: string;
  language: string;
  transliterations: string[];
  fuzzyScore: number;
  phoneticScore: number;
  sanctionsMatches: SanctionsMatch[];
  pepIndicators: PEPIndicator[];
  adverseMedia: AdverseMedia[];
  countryRisk: CountryRiskResult;
  overallRiskScore: number;
  investigationNotes: string[];
  recommendations: string[];
}

interface SanctionsMatch {
  list: string;
  name: string;
  matchScore: number;
  matchType: string;
  details: string;
}

interface PEPIndicator {
  position: string;
  country: string;
  riskLevel: string;
  source: string;
}

interface AdverseMedia {
  headline: string;
  source: string;
  date: string;
  summary: string;
}

interface CountryRiskResult {
  country: string;
  score: number;
  factors: string[];
}

// Sanctions Program Categories
const sanctionsPrograms = [
  {
    category: "Criminal Activities",
    programs: [
      { id: "drug_trafficking", name: "Drug Trafficking (Kingpin Act)", description: "Significant foreign narcotics traffickers" },
      { id: "oil_smuggling", name: "Oil Smuggling & Energy Fraud", description: "Illicit oil trade and sanctions evasion" },
      { id: "arms_trafficking", name: "Arms Trafficking & Weapons Proliferation", description: "Illicit arms trade and military equipment" },
      { id: "human_trafficking", name: "Human Trafficking", description: "Modern slavery and human smuggling networks" },
      { id: "wildlife_trafficking", name: "Wildlife Trafficking", description: "Illegal wildlife trade and poaching networks" },
      { id: "cybercrime", name: "Cybercrime & Ransomware", description: "Cyber-enabled financial crime" },
      { id: "money_laundering", name: "Money Laundering Organizations", description: "Professional money laundering networks" },
    ]
  },
  {
    category: "Terrorist Financing",
    programs: [
      { id: "terrorist_groups", name: "Terrorist Organizations", description: "Designated terrorist groups and affiliates" },
      { id: "terrorist_financiers", name: "Terrorist Financiers", description: "Individuals and entities funding terrorism" },
      { id: "extremist_groups", name: "Violent Extremist Groups", description: "Domestic and international extremist organizations" },
    ]
  },
  {
    category: "Territory-Based Sanctions",
    programs: [
      { id: "russia_sanctions", name: "Russia (Comprehensive)", description: "Full blocking sanctions on Russia" },
      { id: "iran_sanctions", name: "Iran (Comprehensive)", description: "Primary and secondary sanctions on Iran" },
      { id: "north_korea", name: "North Korea (DPRK)", description: "Comprehensive sanctions on DPRK" },
      { id: "syria_sanctions", name: "Syria", description: "Syrian government and affiliated entities" },
      { id: "crimea", name: "Crimea & Sevastopol", description: "Occupied Ukrainian territories" },
      { id: "donetsk_luhansk", name: "Donetsk & Luhansk Regions", description: "Russian-occupied eastern Ukraine" },
      { id: "cuba_sanctions", name: "Cuba", description: "Cuban government and military entities" },
      { id: "venezuela_sanctions", name: "Venezuela", description: "Maduro regime and state oil company" },
      { id: "myanmar_sanctions", name: "Myanmar (Burma)", description: "Military junta and affiliated businesses" },
      { id: "belarus_sanctions", name: "Belarus", description: "Lukashenko regime and supporters" },
    ]
  },
  {
    category: "Proliferation Activities",
    programs: [
      { id: "nuclear_proliferation", name: "Weapons of Mass Destruction", description: "WMD proliferators and their support networks" },
      { id: "missile_technology", name: "Missile Technology Proliferation", description: "Ballistic missile technology networks" },
      { id: "dual_use_goods", name: "Dual-Use Goods & Technology", description: "Items with military and civilian applications" },
    ]
  },
  {
    category: "Government Corruption",
    programs: [
      { id: "foreign_corruption", name: "Foreign Government Corruption", description: "Corrupt foreign officials and their associates" },
      { id: "kleptocracy", name: "Kleptocracy & Asset Recovery", description: "Stolen assets from foreign governments" },
      { id: "magnitsky", name: "Magnitsky Human Rights Abusers", description: "Human rights violators and corrupt officials" },
    ]
  },
  {
    category: "Industry-Specific",
    programs: [
      { id: "diamond_trade", name: "Diamond Trade (Blood Diamonds)", description: "Conflict diamond networks" },
      { id: "precious_metals", name: "Precious Metals & Minerals", description: "Conflict minerals and precious metals" },
      { id: "maritime_shipping", name: "Maritime Shipping & Vessels", description: "Sanctioned vessels and shipping companies" },
      { id: "financial_institutions", name: "Sanctioned Financial Institutions", description: "Banks and payment processors" },
    ]
  }
];

export default function ScreeningEngine() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<ScreeningResult | null>(null);
  const [activeTab, setActiveTab] = useState<"sanctions" | "pep" | "media" | "country">("sanctions");
  
  // Sanctions filter state
  const [selectedPrograms, setSelectedPrograms] = useState<string[]>([]);
  const [showProgramDropdown, setShowProgramDropdown] = useState(false);

  const toggleProgram = (programId: string) => {
    setSelectedPrograms(prev => 
      prev.includes(programId) 
        ? prev.filter(id => id !== programId)
        : [...prev, programId]
    );
  };

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setResults(null);

    // Simulate screening process
    setTimeout(() => {
      const mockResult: ScreeningResult = {
        submittedName: searchQuery,
        normalizedName: searchQuery.toUpperCase(),
        language: "English",
        transliterations: [
          searchQuery.toUpperCase(),
          searchQuery.toLowerCase(),
          searchQuery.split("").reverse().join(""),
        ],
        fuzzyScore: Math.floor(Math.random() * 30) + 70,
        phoneticScore: Math.floor(Math.random() * 20) + 75,
        sanctionsMatches: [
          {
            list: "OFAC SDN",
            name: searchQuery + " Holdings Ltd",
            matchScore: 94,
            matchType: "Fuzzy Match",
            details: "Entity appears on OFAC SDN list with high similarity score"
          },
          {
            list: "EU Sanctions",
            name: searchQuery + " Trading Co",
            matchScore: 78,
            matchType: "Phonetic Match",
            details: "Phonetic similarity to EU sanctioned entity"
          }
        ],
        pepIndicators: [
          {
            position: "Former Government Minister",
            country: "Russia",
            riskLevel: "High",
            source: "World-Check"
          },
          {
            position: "State-Owned Enterprise Director",
            country: "China",
            riskLevel: "Medium",
            source: "Dow Jones"
          }
        ],
        adverseMedia: [
          {
            headline: "Investigation links entity to money laundering network",
            source: "Reuters",
            date: "2024-01-15",
            summary: "Global authorities are investigating potential connections to organized crime"
          },
          {
            headline: "Regulatory fine for compliance failures",
            source: "Financial Times",
            date: "2023-11-20",
            summary: "Entity fined $5M for AML control deficiencies"
          }
        ],
        countryRisk: {
          country: "Multiple",
          score: 72,
          factors: [
            "Operations in high-risk jurisdiction",
            "Cross-border transactions with sanctioned countries",
            "Shell company structures in tax havens"
          ]
        },
        overallRiskScore: Math.floor(Math.random() * 40) + 55,
        investigationNotes: [
          "Entity exhibits characteristics consistent with shell company",
          "Beneficial ownership structure requires verification",
          "Transaction patterns suggest potential layering"
        ],
        recommendations: [
          "Conduct enhanced due diligence",
          "Request additional ownership documentation",
          "Monitor transactions for 90 days",
          "Consider senior management approval"
        ]
      };

      setResults(mockResult);
      setIsSearching(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-1">Name Screening Engine</h1>
        <p className="text-slate-400">AI-powered entity screening with fuzzy matching and transliteration support</p>
      </motion.div>

      {/* Search Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-6"
      >
        <div className="flex gap-4 mb-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Enter entity name, alias, or identification number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 pl-12 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSearch}
            disabled={isSearching || !searchQuery.trim()}
            className="px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isSearching ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Screening...
              </>
            ) : (
              <>
                <Shield size={18} />
                Screen Entity
              </>
            )}
          </motion.button>
        </div>

        {/* Sanctions Program Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowProgramDropdown(!showProgramDropdown)}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 text-left flex items-center justify-between hover:border-slate-600 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Filter size={18} className="text-slate-400" />
              <span className="text-slate-300">
                {selectedPrograms.length === 0 
                  ? "Select Sanctions Programs & Categories (Optional)" 
                  : `${selectedPrograms.length} Programs Selected`}
              </span>
            </div>
            <ChevronDown 
              size={18} 
              className={`text-slate-400 transition-transform ${showProgramDropdown ? "rotate-180" : ""}`} 
            />
          </button>

          <AnimatePresence>
            {showProgramDropdown && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute z-50 w-full mt-2 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl max-h-96 overflow-y-auto"
              >
                {sanctionsPrograms.map((category) => (
                  <div key={category.category} className="border-b border-slate-700 last:border-b-0">
                    <div className="px-4 py-2 bg-slate-900 sticky top-0">
                      <h3 className="text-sm font-semibold text-blue-400">{category.category}</h3>
                    </div>
                    <div className="p-2">
                      {category.programs.map((program) => (
                        <label
                          key={program.id}
                          className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-700/50 cursor-pointer transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={selectedPrograms.includes(program.id)}
                            onChange={() => toggleProgram(program.id)}
                            className="mt-1 w-4 h-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500 focus:ring-offset-slate-800"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-white text-sm font-medium">{program.name}</span>
                              {selectedPrograms.includes(program.id) && (
                                <CheckCircle size={14} className="text-green-400" />
                              )}
                            </div>
                            <p className="text-slate-500 text-xs">{program.description}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
                
                {/* Footer Actions */}
                <div className="sticky bottom-0 bg-slate-900 border-t border-slate-700 p-3 flex justify-between">
                  <button
                    onClick={() => setSelectedPrograms([])}
                    className="text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={() => setShowProgramDropdown(false)}
                    className="px-4 py-1.5 bg-blue-500 text-white text-sm rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Apply ({selectedPrograms.length})
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Selected Programs Tags */}
        {selectedPrograms.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {selectedPrograms.map((programId) => {
              const program = sanctionsPrograms
                .flatMap(c => c.programs)
                .find(p => p.id === programId);
              if (!program) return null;
              return (
                <motion.span
                  key={programId}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-xs flex items-center gap-2"
                >
                  {program.name}
                  <button
                    onClick={() => toggleProgram(programId)}
                    className="hover:text-white transition-colors"
                  >
                    ×
                  </button>
                </motion.span>
              );
            })}
          </div>
        )}

        {/* Data Sources */}
        <div className="mt-4 flex items-center gap-2 flex-wrap">
          <span className="text-xs text-slate-500">Screening against:</span>
          {dataSources.slice(0, 6).map((source, i) => (
            <span key={i} className="px-2 py-1 bg-slate-800 text-slate-400 rounded text-xs">
              {source}
            </span>
          ))}
          <span className="text-xs text-slate-500">+{dataSources.length - 6} more</span>
        </div>
      </motion.div>

      {/* Results */}
      <AnimatePresence mode="wait">
        {results && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {/* Overview */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 }}
                className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center"
              >
                <RiskGauge score={results.overallRiskScore} label="Overall Risk" size="lg" />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="bg-slate-900 border border-slate-800 rounded-xl p-6"
              >
                <h3 className="text-slate-400 text-sm mb-2">Fuzzy Match Score</h3>
                <p className="text-3xl font-bold text-white">{results.fuzzyScore}%</p>
                <div className="mt-2 h-2 bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${results.fuzzyScore}%` }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                    className="h-full bg-blue-500"
                  />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                className="bg-slate-900 border border-slate-800 rounded-xl p-6"
              >
                <h3 className="text-slate-400 text-sm mb-2">Phonetic Score</h3>
                <p className="text-3xl font-bold text-white">{results.phoneticScore}%</p>
                <div className="mt-2 h-2 bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${results.phoneticScore}%` }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                    className="h-full bg-purple-500"
                  />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 }}
                className="bg-slate-900 border border-slate-800 rounded-xl p-6"
              >
                <h3 className="text-slate-400 text-sm mb-2">Matches Found</h3>
                <p className="text-3xl font-bold text-white">
                  {results.sanctionsMatches.length + results.pepIndicators.length + results.adverseMedia.length}
                </p>
                <p className="text-xs text-slate-500 mt-2">
                  {results.sanctionsMatches.length} sanctions, {results.pepIndicators.length} PEP, {results.adverseMedia.length} media
                </p>
              </motion.div>
            </div>

            {/* Tabs */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="flex border-b border-slate-800">
                {[
                  { id: "sanctions" as const, label: "Sanctions", count: results.sanctionsMatches.length, icon: Shield },
                  { id: "pep" as const, label: "PEP", count: results.pepIndicators.length, icon: User },
                  { id: "media" as const, label: "Adverse Media", count: results.adverseMedia.length, icon: Newspaper },
                  { id: "country" as const, label: "Country Risk", count: 1, icon: Globe },
                ].map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex-1 px-4 py-3 flex items-center justify-center gap-2 transition-colors ${
                        activeTab === tab.id
                          ? "bg-slate-800 text-white border-b-2 border-blue-500"
                          : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                      }`}
                    >
                      <Icon size={16} />
                      <span>{tab.label}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs ${
                        tab.count > 0 ? "bg-red-500/20 text-red-400" : "bg-slate-700 text-slate-400"
                      }`}>
                        {tab.count}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="p-6">
                <AnimatePresence mode="wait">
                  {activeTab === "sanctions" && (
                    <motion.div
                      key="sanctions"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="space-y-4"
                    >
                      {results.sanctionsMatches.length === 0 ? (
                        <div className="text-center py-8 text-slate-500">
                          <CheckCircle size={48} className="mx-auto mb-4 text-green-500" />
                          <p>No sanctions matches found</p>
                        </div>
                      ) : (
                        results.sanctionsMatches.map((match, i) => (
                          <IntelligenceCard
                            key={i}
                            type="sanctions"
                            title={match.name}
                            description={match.details}
                            severity={match.matchScore >= 90 ? "critical" : match.matchScore >= 70 ? "high" : "medium"}
                            details={[`${match.list} • ${match.matchType} • ${match.matchScore}% match`]}
                          />
                        ))
                      )}
                    </motion.div>
                  )}

                  {activeTab === "pep" && (
                    <motion.div
                      key="pep"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="space-y-4"
                    >
                      {results.pepIndicators.length === 0 ? (
                        <div className="text-center py-8 text-slate-500">
                          <CheckCircle size={48} className="mx-auto mb-4 text-green-500" />
                          <p>No PEP indicators found</p>
                        </div>
                      ) : (
                        results.pepIndicators.map((pep, i) => (
                          <IntelligenceCard
                            key={i}
                            type="pep"
                            title={pep.position}
                            description={`Position identified in ${pep.country}`}
                            severity={pep.riskLevel === "High" ? "high" : "medium"}
                            details={[`Source: ${pep.source}`]}
                          />
                        ))
                      )}
                    </motion.div>
                  )}

                  {activeTab === "media" && (
                    <motion.div
                      key="media"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="space-y-4"
                    >
                      {results.adverseMedia.length === 0 ? (
                        <div className="text-center py-8 text-slate-500">
                          <CheckCircle size={48} className="mx-auto mb-4 text-green-500" />
                          <p>No adverse media found</p>
                        </div>
                      ) : (
                        results.adverseMedia.map((media, i) => (
                          <IntelligenceCard
                            key={i}
                            type="adverse"
                            title={media.headline}
                            description={media.summary}
                            severity="high"
                            details={[`${media.source} • ${media.date}`]}
                          />
                        ))
                      )}
                    </motion.div>
                  )}

                  {activeTab === "country" && (
                    <motion.div
                      key="country"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="space-y-4"
                    >
                      <div className="flex items-center gap-6">
                        <RiskGauge score={results.countryRisk.score} label="Country Risk" size="md" />
                        <div className="flex-1">
                          <h4 className="text-white font-semibold mb-2">Risk Factors</h4>
                          <ul className="space-y-2">
                            {results.countryRisk.factors.map((factor, i) => (
                              <li key={i} className="flex items-center gap-2 text-slate-300">
                                <AlertTriangle size={14} className="text-yellow-400" />
                                {factor}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Recommendations */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-slate-900 border border-slate-800 rounded-xl p-6"
            >
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <Link2 size={18} className="text-blue-400" />
                Investigation Notes & Recommendations
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-slate-400 text-sm mb-2">Investigation Notes</h4>
                  <ul className="space-y-2">
                    {results.investigationNotes.map((note, i) => (
                      <li key={i} className="flex items-start gap-2 text-slate-300 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-orange-400 mt-2" />
                        {note}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="text-slate-400 text-sm mb-2">Recommended Actions</h4>
                  <ul className="space-y-2">
                    {results.recommendations.map((rec, i) => (
                      <li key={i} className="flex items-start gap-2 text-slate-300 text-sm">
                        <CheckCircle size={14} className="text-green-400 mt-0.5" />
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Empty State */}
      {!results && !isSearching && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <Shield size={64} className="mx-auto mb-4 text-slate-700" />
          <h3 className="text-xl font-semibold text-white mb-2">Ready to Screen</h3>
          <p className="text-slate-400 mb-4">Enter an entity name to begin the screening process</p>
          <p className="text-xs text-slate-500">
            Powered by AI fuzzy matching, phonetic analysis, and transliteration support
          </p>
        </motion.div>
      )}
    </div>
  );
}