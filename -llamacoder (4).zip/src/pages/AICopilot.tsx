import { useState } from "react";
import { motion } from "framer-motion";
import { Bot, Send, Sparkles, AlertTriangle, Shield, FileText, MessageSquare, Lightbulb, ArrowRight } from "lucide-react";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const initialMessages: Message[] = [
  {
    id: 1,
    role: "assistant",
    content: "Hello! I'm your AML AI Copilot. I can help you with:\n\n• Investigating alerts and explaining risk factors\n• Generating SAR narratives\n• Analyzing transaction patterns\n• Identifying beneficial ownership structures\n• Recommending next steps for cases\n\nHow can I assist you today?",
    timestamp: new Date()
  }
];

const suggestions = [
  "Explain why this alert was triggered",
  "Generate a SAR narrative for this case",
  "Analyze the transaction pattern",
  "Identify beneficial ownership risks",
  "Recommend next investigation steps",
  "Summarize the entity's risk profile"
];

export default function AICopilot() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      role: "user",
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const responses: { [key: string]: string } = {
        "explain": "Based on my analysis, this alert was triggered due to:\n\n1. **Sanctions Match**: The entity name 'Global Trading Corp' has a 94% fuzzy match with an OFAC SDN entry\n2. **Transaction Pattern**: Unusual round-dollar transactions totaling $2.4M over 30 days\n3. **Geographic Risk**: Transactions involving high-risk jurisdiction (Iran)\n4. **Adverse Media**: News article linking entity to oil smuggling investigation\n\n**Recommended Action**: Escalate to Level 2 investigation and request senior management approval.",
        "sar": "**Suspicious Activity Report - Draft Narrative**\n\nOn [DATE], this institution identified unusual activity in account [ACCOUNT] held by [ENTITY]. The account exhibited the following suspicious characteristics:\n\n1. Multiple round-dollar wire transfers totaling $2,450,000\n2. Transactions with counterparties in sanctioned jurisdictions\n3. Rapid movement of funds within 48 hours of receipt\n4. Beneficial ownership structure involving shell companies\n\nThe activity is inconsistent with the customer's stated business purpose. This institution has no reasonable explanation for the transactions and is filing this SAR pursuant to 31 CFR 1020.320.",
        "analyze": "**Transaction Pattern Analysis**\n\nI've identified the following patterns:\n\n• **Structuring Indicators**: 12 transactions just below $10,000 threshold\n• **Velocity**: Average 3.2 days between receipt and transfer\n• **Geographic Flow**: Funds routed through UAE → Singapore → Panama\n• **Round Dollar Amounts**: 78% of transactions are round numbers\n\n**Risk Score**: 87/100 (Critical)\n\nThis pattern is consistent with layering behavior commonly seen in trade-based money laundering.",
        "beneficial": "**Beneficial Ownership Analysis**\n\nI've traced the ownership structure through 4 layers:\n\n```\nGlobal Trading Corp (Target)\n└── Pacific Holdings Ltd (50%)\n    └── Crown Enterprises (100%)\n        └── Nordic Investments AS (Shell)\n            └── [ULTIMATE BENEFICIAL OWNER - UNVERIFIED]\n```\n\n**Risk Factors**:\n• 4-layer ownership structure (typical for obfuscation)\n• Nordic Investments AS is a known shell company jurisdiction\n• No verified natural person as ultimate beneficial owner\n\n**Recommendation**: Request full ownership documentation and verify identity of ultimate beneficial owner.",
        "recommend": "**Investigation Recommendations**\n\nBased on my analysis, here are the prioritized next steps:\n\n1. **Immediate** (24-48 hours):\n   - Request updated KYC documentation\n   - Place temporary hold on outgoing transactions\n   - Notify compliance officer\n\n2. **Short-term** (1-2 weeks):\n   - Conduct enhanced due diligence on counterparties\n   - Review last 12 months of transaction history\n   - Search for adverse media on beneficial owners\n\n3. **Documentation**:\n   - Document all findings in case management system\n   - Prepare SAR narrative if suspicion confirmed\n   - Retain all evidence for regulatory examination",
        "summarize": "**Entity Risk Profile Summary**\n\n| Factor | Score | Status |\n|--------|-------|--------|\n| Sanctions Risk | 94 | Critical |\n| PEP Exposure | 45 | Medium |\n| Adverse Media | 78 | High |\n| Country Risk | 88 | Critical |\n| Transaction Risk | 82 | High |\n\n**Overall Risk Score: 77/100 (High Risk)**\n\n**Key Concerns**:\n- Potential OFAC match requiring immediate attention\n- Geographic exposure to sanctioned jurisdictions\n- Complex ownership structure with opacity risks\n\n**Regulatory Impact**: Potential for enforcement action if not properly mitigated."
      };

      let responseContent = "I'd be happy to help with that. Could you provide more details about the specific case or entity you're investigating? For example:\n\n• The case ID or alert number\n• The entity name or transaction reference\n• Specific questions you need answered\n\nThis will allow me to provide more targeted assistance.";

      const inputLower = input.toLowerCase();
      if (inputLower.includes("explain") || inputLower.includes("why")) {
        responseContent = responses["explain"];
      } else if (inputLower.includes("sar") || inputLower.includes("narrative")) {
        responseContent = responses["sar"];
      } else if (inputLower.includes("pattern") || inputLower.includes("analyze")) {
        responseContent = responses["analyze"];
      } else if (inputLower.includes("beneficial") || inputLower.includes("ownership")) {
        responseContent = responses["beneficial"];
      } else if (inputLower.includes("recommend") || inputLower.includes("next") || inputLower.includes("steps")) {
        responseContent = responses["recommend"];
      } else if (inputLower.includes("summarize") || inputLower.includes("profile")) {
        responseContent = responses["summarize"];
      }

      const assistantMessage: Message = {
        id: messages.length + 2,
        role: "assistant",
        content: responseContent,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6 flex flex-col">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center gap-3 mb-1">
          <div className="p-2 bg-purple-500/20 rounded-lg">
            <Bot size={24} className="text-purple-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">AI AML Copilot</h1>
            <p className="text-slate-400">Intelligent investigation assistant powered by advanced AI</p>
          </div>
        </div>
      </motion.div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Chat Area */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-xl flex flex-col"
        >
          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 min-h-[400px] max-h-[500px]">
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`max-w-[80%] rounded-xl p-4 ${
                  message.role === "user"
                    ? "bg-blue-500 text-white"
                    : "bg-slate-800 text-slate-200"
                }`}>
                  {message.role === "assistant" && (
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles size={14} className="text-purple-400" />
                      <span className="text-xs text-purple-400 font-medium">AI Copilot</span>
                    </div>
                  )}
                  <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                </div>
              </motion.div>
            ))}
            {isTyping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-start"
              >
                <div className="bg-slate-800 rounded-xl p-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Input */}
          <div className="p-4 border-t border-slate-800">
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Ask about investigations, SARs, risk analysis..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                className="px-4 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Suggestions */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <Lightbulb size={16} className="text-yellow-400" />
              Quick Actions
            </h3>
            <div className="space-y-2">
              {suggestions.map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => setInput(suggestion)}
                  className="w-full text-left px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm text-slate-300 transition-colors flex items-center justify-between group"
                >
                  <span>{suggestion}</span>
                  <ArrowRight size={14} className="text-slate-500 group-hover:text-slate-300" />
                </button>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <FileText size={16} className="text-blue-400" />
              Recent Context
            </h3>
            <div className="space-y-2">
              <div className="p-2 bg-slate-800 rounded-lg">
                <p className="text-xs text-slate-400">Case #C-2024-0847</p>
                <p className="text-sm text-white">Global Trading Corp</p>
              </div>
              <div className="p-2 bg-slate-800 rounded-lg">
                <p className="text-xs text-slate-400">Alert #A-2024-1234</p>
                <p className="text-sm text-white">Pacific Holdings Ltd</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}