import { useState } from "react";
import { motion } from "framer-motion";
import { Shield, AlertTriangle, Search, Filter, Download, Clock, Globe, User, Building2 } from "lucide-react";
import IntelligenceCard from "../components/IntelligenceCard";
import { dataSources } from "../data/mockData";

interface SanctionEntity {
  id: string;
  name: string;
  type: "individual" | "entity";
  program: string;
  listDate: string;
  country: string;
  risk: "critical" | "high" | "medium";
  aliases: string[];
  details: string;
}

const sanctionEntities: SanctionEntity[] = [
  {
    id: "S001",
    name: "Global Trading Corporation",
    type: "entity",
    program: "OFAC SDN",
    listDate: "2024-01-15",
    country: "Iran",
    risk: "critical",
    aliases: ["GTC", "Global Trade Co", "GTC Holdings"],
    details: "Involved in oil smuggling and sanctions evasion networks"
  },
  {
    id: "S002",
    name: "Ivan Petrov",
    type: "individual",
    program: "EU Sanctions",
    listDate: "2024-02-20",
    country: "Russia",
    risk: "critical",
    aliases: ["I. Petrov", "Petrov Ivan"],
    details: "Oligarch with connections to sanctioned banks"
  },
  {
    id: "S003",
    name: "Pacific Holdings Ltd",
    type: "entity",
    program: "UN Security Council",
    listDate: "2023-11-08",
    country: "North Korea",
    risk: "critical",
    aliases: ["Pacific Holdings", "PHL Group"],
    details: "Front company for proliferation financing"
  },
  {
    id: "S004",
    name: "Ahmed Al-Rashid",
    type: "individual",
    program: "OFAC SDN",
    listDate: "2024-03-01",
    country: "Syria",
    risk: "high",
    aliases: ["A. Al-Rashid", "Al-Rashid Ahmed"],
    details: "Connected to terrorist financing networks"
  },
  {
    id: "S005",
    name: "Nordic Investments AS",
    type: "entity",
    program: "UK Sanctions",
    listDate: "2024-01-28",
    country: "Russia",
    risk: "high",
    aliases: ["Nordic Invest", "NIAS"],
    details: "Shell company for asset hiding"
  }
];

export default function SanctionsIntelligence() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProgram, setSelectedProgram] = useState<string>("all");
  const [selectedType, setSelectedType] = useState<string>("all");

  const programs = ["all", "OFAC SDN", "EU Sanctions", "UN Security Council", "UK Sanctions"];

  const filteredEntities = sanctionEntities.filter(entity => {
    const matchesSearch = entity.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entity.aliases.some(a => a.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesProgram = selectedProgram === "all" || entity.program === selectedProgram;
    const matchesType = selectedType === "all" || entity.type === selectedType;
    return matchesSearch && matchesProgram && matchesType;
  });

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-1">Sanctions Intelligence</h1>
        <p className="text-slate-400">Real-time sanctions list monitoring and entity tracking</p>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: "Total Entities", value: "15,847", color: "blue" },
          { label: "Critical Matches", value: "23", color: "red" },
          { label: "New This Week", value: "156", color: "orange" },
          { label: "Last Updated", value: "2 min ago", color: "green" },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-4"
          >
            <p className="text-slate-400 text-sm">{stat.label}</p>
            <p className={`text-2xl font-bold ${
              stat.color === "blue" ? "text-blue-400" :
              stat.color === "red" ? "text-red-400" :
              stat.color === "orange" ? "text-orange-400" : "text-green-400"
            }`}>{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-6">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <div className="relative">
              <input
                type="text"
                placeholder="Search entities or aliases..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 pl-10 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            </div>
          </div>
          <select
            value={selectedProgram}
            onChange={(e) => setSelectedProgram(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500"
          >
            {programs.map(p => (
              <option key={p} value={p}>{p === "all" ? "All Programs" : p}</option>
            ))}
          </select>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Types</option>
            <option value="individual">Individuals</option>
            <option value="entity">Entities</option>
          </select>
          <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center gap-2">
            <Download size={16} />
            Export
          </button>
        </div>
      </div>

      {/* Entity List */}
      <div className="space-y-4">
        {filteredEntities.map((entity, i) => (
          <motion.div
            key={entity.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-colors"
          >
            <div className="flex items-start gap-4">
              <div className={`p-3 rounded-lg ${
                entity.risk === "critical" ? "bg-red-500/20" : "bg-orange-500/20"
              }`}>
                {entity.type === "individual" ? (
                  <User size={20} className={entity.risk === "critical" ? "text-red-400" : "text-orange-400"} />
                ) : (
                  <Building2 size={20} className={entity.risk === "critical" ? "text-red-400" : "text-orange-400"} />
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-white font-semibold">{entity.name}</h3>
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                    entity.risk === "critical" ? "bg-red-500/20 text-red-400" : "bg-orange-500/20 text-orange-400"
                  }`}>
                    {entity.risk.toUpperCase()}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-slate-400 mb-2">
                  <span className="flex items-center gap-1">
                    <Shield size={14} />
                    {entity.program}
                  </span>
                  <span className="flex items-center gap-1">
                    <Globe size={14} />
                    {entity.country}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={14} />
                    Listed: {entity.listDate}
                  </span>
                </div>
                <p className="text-slate-300 text-sm mb-2">{entity.details}</p>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500">Aliases:</span>
                  {entity.aliases.map((alias, j) => (
                    <span key={j} className="px-2 py-0.5 bg-slate-800 text-slate-400 rounded text-xs">
                      {alias}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Data Sources */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-8 bg-slate-900 border border-slate-800 rounded-xl p-4"
      >
        <h3 className="text-white font-semibold mb-3">Connected Data Sources</h3>
        <div className="flex flex-wrap gap-2">
          {dataSources.map((source, i) => (
            <span key={i} className="px-3 py-1 bg-slate-800 text-slate-400 rounded-full text-sm">
              {source}
            </span>
          ))}
        </div>
      </motion.div>
    </div>
  );
}