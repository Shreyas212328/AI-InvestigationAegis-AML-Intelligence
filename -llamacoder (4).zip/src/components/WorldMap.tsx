import { motion } from "framer-motion";

interface CountryData {
  name: string;
  code: string;
  risk: number;
  x: number;
  y: number;
}

const countries: CountryData[] = [
  { name: "Iran", code: "IR", risk: 98, x: 58, y: 42 },
  { name: "North Korea", code: "KP", risk: 99, x: 82, y: 35 },
  { name: "Syria", code: "SY", risk: 95, x: 54, y: 42 },
  { name: "Russia", code: "RU", risk: 88, x: 62, y: 30 },
  { name: "Afghanistan", code: "AF", risk: 92, x: 64, y: 42 },
  { name: "Myanmar", code: "MM", risk: 85, x: 75, y: 48 },
  { name: "Venezuela", code: "VE", risk: 82, x: 24, y: 52 },
  { name: "Cuba", code: "CU", risk: 75, x: 22, y: 45 },
  { name: "Sudan", code: "SD", risk: 80, x: 52, y: 50 },
  { name: "Yemen", code: "YE", risk: 88, x: 56, y: 48 },
  { name: "Libya", code: "LY", risk: 78, x: 50, y: 42 },
  { name: "Zimbabwe", code: "ZW", risk: 72, x: 54, y: 65 },
  { name: "Belarus", code: "BY", risk: 70, x: 56, y: 32 },
  { name: "China", code: "CN", risk: 45, x: 76, y: 40 },
  { name: "Turkey", code: "TR", risk: 55, x: 54, y: 40 },
  { name: "UAE", code: "AE", risk: 48, x: 58, y: 46 },
  { name: "Saudi Arabia", code: "SA", risk: 52, x: 56, y: 48 },
  { name: "Pakistan", code: "PK", risk: 68, x: 64, y: 44 },
  { name: "Nigeria", code: "NG", risk: 58, x: 48, y: 52 },
  { name: "Brazil", code: "BR", risk: 42, x: 30, y: 58 },
  { name: "Mexico", code: "MX", risk: 55, x: 16, y: 48 },
  { name: "USA", code: "US", risk: 25, x: 14, y: 40 },
  { name: "UK", code: "GB", risk: 20, x: 46, y: 32 },
  { name: "Germany", code: "DE", risk: 18, x: 50, y: 34 },
  { name: "Japan", code: "JP", risk: 22, x: 86, y: 38 },
  { name: "Singapore", code: "SG", risk: 28, x: 74, y: 52 },
  { name: "Switzerland", code: "CH", risk: 15, x: 48, y: 36 },
  { name: "Cayman Islands", code: "KY", risk: 65, x: 20, y: 50 },
  { name: "British Virgin Is.", code: "VG", risk: 68, x: 24, y: 48 },
  { name: "Panama", code: "PA", risk: 60, x: 20, y: 52 },
];

interface WorldMapProps {
  onCountryClick?: (country: CountryData) => void;
  selectedCountry?: string | null;
}

export default function WorldMap({ onCountryClick, selectedCountry }: WorldMapProps) {
  const getRiskColor = (risk: number) => {
    if (risk >= 80) return "bg-red-500";
    if (risk >= 60) return "bg-orange-500";
    if (risk >= 40) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <div className="relative w-full h-64 bg-slate-800/30 rounded-xl overflow-hidden">
      {/* Country Points */}
      {countries.map((country) => (
        <motion.button
          key={country.code}
          whileHover={{ scale: 1.5 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => onCountryClick?.(country)}
          className={`absolute w-3 h-3 rounded-full ${getRiskColor(country.risk)} cursor-pointer transition-all ${
            selectedCountry === country.code ? "ring-2 ring-white ring-offset-1 ring-offset-slate-900" : ""
          }`}
          style={{ left: `${country.x}%`, top: `${country.y}%` }}
          title={country.name}
        >
          <span className="sr-only">{country.name}</span>
        </motion.button>
      ))}

      {/* Legend */}
      <div className="absolute bottom-2 left-2 flex items-center gap-3 text-xs">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-red-500" />
          <span className="text-slate-400">Critical</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-orange-500" />
          <span className="text-slate-400">High</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-yellow-500" />
          <span className="text-slate-400">Medium</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          <span className="text-slate-400">Low</span>
        </div>
      </div>
    </div>
  );
}

export { countries };
export type { CountryData };