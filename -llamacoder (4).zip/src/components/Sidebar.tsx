import { motion } from "framer-motion";
import {
  LayoutDashboard,
  Search,
  Shield,
  Globe,
  Bot,
  FolderOpen,
} from "lucide-react";
import { Page } from "../App";

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const navItems = [
  { id: 'dashboard' as Page, label: 'Dashboard', icon: LayoutDashboard },
  { id: 'screening' as Page, label: 'Name Screening', icon: Search },
  { id: 'sanctions' as Page, label: 'Sanctions Intel', icon: Shield },
  { id: 'country' as Page, label: 'Country Risk', icon: Globe },
  { id: 'ai' as Page, label: 'AI Copilot', icon: Bot },
  { id: 'cases' as Page, label: 'Case Management', icon: FolderOpen },
];

export default function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  return (
    <motion.div
      initial={{ x: -100 }}
      animate={{ x: 0 }}
      className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col"
    >
      {/* Logo */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
            <Shield className="text-white" size={20} />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg">AML Intel</h1>
            <p className="text-slate-500 text-xs">Financial Crime Platform</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <motion.button
              key={item.id}
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive
                  ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon size={18} />
              <span className="font-medium">{item.label}</span>
            </motion.button>
          );
        })}
      </nav>

      {/* Live Status */}
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs text-slate-400">System Status</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">API Status</span>
              <span className="text-green-400">Operational</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Data Sync</span>
              <span className="text-green-400">Live</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}