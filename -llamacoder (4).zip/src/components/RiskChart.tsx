import { motion } from "framer-motion";
import { riskScores } from "../data/mockData";

export default function RiskChart() {
  const maxValue = Math.max(...riskScores.flatMap(d => [d.high, d.medium, d.low]));
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="bg-slate-900 border border-slate-800 rounded-xl p-6"
    >
      <h3 className="text-white font-semibold mb-6">Risk Distribution Trend</h3>
      
      <div className="flex items-end gap-4 h-48">
        {riskScores.map((data, index) => (
          <motion.div
            key={data.month}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + index * 0.1 }}
            className="flex-1 flex flex-col items-center gap-2"
          >
            <div className="w-full flex flex-col gap-1" style={{ height: "180px" }}>
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${(data.high / maxValue) * 100}%` }}
                transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
                className="w-full bg-red-500 rounded-t"
              />
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${(data.medium / maxValue) * 100}%` }}
                transition={{ delay: 0.65 + index * 0.1, duration: 0.5 }}
                className="w-full bg-orange-500"
              />
              <motion.div
                initial={{ height: 0 }}
                animate={{ height: `${(data.low / maxValue) * 100}%` }}
                transition={{ delay: 0.7 + index * 0.1, duration: 0.5 }}
                className="w-full bg-blue-500 rounded-b"
              />
            </div>
            <span className="text-xs text-slate-400">{data.month}</span>
          </motion.div>
        ))}
      </div>
      
      <div className="flex items-center justify-center gap-6 mt-6">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded" />
          <span className="text-xs text-slate-400">High Risk</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-orange-500 rounded" />
          <span className="text-xs text-slate-400">Medium Risk</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded" />
          <span className="text-xs text-slate-400">Low Risk</span>
        </div>
      </div>
    </motion.div>
  );
}