import { motion } from "framer-motion";
import { AlertTriangle, Users, Clock, TrendingUp, TrendingDown, Shield } from "lucide-react";

interface KPICardProps {
  title: string;
  value: string | number;
  change: number;
  icon: "alerts" | "customers" | "time" | "shield";
  color: "red" | "orange" | "blue" | "green";
  index: number;
}

const iconMap = {
  alerts: AlertTriangle,
  customers: Users,
  time: Clock,
  shield: Shield,
};

const colorMap = {
  red: { bg: "bg-red-500/10", border: "border-red-500/20", text: "text-red-400", icon: "text-red-500" },
  orange: { bg: "bg-orange-500/10", border: "border-orange-500/20", text: "text-orange-400", icon: "text-orange-500" },
  blue: { bg: "bg-blue-500/10", border: "border-blue-500/20", text: "text-blue-400", icon: "text-blue-500" },
  green: { bg: "bg-green-500/10", border: "border-green-500/20", text: "text-green-400", icon: "text-green-500" },
};

export default function KPICard({ title, value, change, icon, color, index }: KPICardProps) {
  const Icon = iconMap[icon];
  const colors = colorMap[color];
  const isPositive = change > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ scale: 1.02, y: -2 }}
      className={`${colors.bg} border ${colors.border} rounded-xl p-5 cursor-pointer`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2 rounded-lg ${colors.bg}`}>
          <Icon size={20} className={colors.icon} />
        </div>
        <div className={`flex items-center gap-1 text-xs ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
          {isPositive ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
          <span>{Math.abs(change)}%</span>
        </div>
      </div>
      <h3 className="text-slate-400 text-sm mb-1">{title}</h3>
      <p className="text-3xl font-bold text-white">{value}</p>
    </motion.div>
  );
}