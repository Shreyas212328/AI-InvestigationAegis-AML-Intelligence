import { motion } from "framer-motion";
import { AlertTriangle, Clock } from "lucide-react";
import { alerts } from "../data/mockData";

export default function AlertTicker() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-800 overflow-hidden"
    >
      <div className="flex items-center gap-4 py-2 px-4">
        <div className="flex items-center gap-2 text-red-400 shrink-0">
          <AlertTriangle size={16} />
          <span className="text-sm font-medium">Live Alerts</span>
        </div>
        
        <div className="relative overflow-hidden flex-1">
          <motion.div
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            className="flex gap-8 whitespace-nowrap"
          >
            {[...alerts, ...alerts].map((alert, index) => (
              <div key={`${alert.id}-${index}`} className="flex items-center gap-3">
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                  alert.severity === "Critical" 
                    ? "bg-red-500/20 text-red-400" 
                    : alert.severity === "High"
                    ? "bg-orange-500/20 text-orange-400"
                    : "bg-yellow-500/20 text-yellow-400"
                }`}>
                  {alert.severity}
                </span>
                <span className="text-sm text-slate-300">{alert.title}</span>
                <span className="text-xs text-slate-500">{alert.timestamp}</span>
              </div>
            ))}
          </motion.div>
        </div>
        
        <div className="flex items-center gap-1 text-slate-500 shrink-0">
          <Clock size={14} />
          <span className="text-xs">Live</span>
        </div>
      </div>
    </motion.div>
  );
}