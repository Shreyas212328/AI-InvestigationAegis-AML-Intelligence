import { motion } from "framer-motion";
import { User, Building, Globe } from "lucide-react";

interface Entity {
  id: string;
  name: string;
  type: "person" | "company" | "country";
  risk: number;
  x: number;
  y: number;
}

interface Connection {
  from: string;
  to: string;
  type: "ownership" | "director" | "family" | "transaction";
}

interface RelationshipNetworkProps {
  entities: Entity[];
  connections: Connection[];
}

export default function RelationshipNetwork({ entities, connections }: RelationshipNetworkProps) {
  const getIcon = (type: string) => {
    switch (type) {
      case "person":
        return User;
      case "company":
        return Building;
      case "country":
        return Globe;
      default:
        return User;
    }
  };

  const getRiskColor = (risk: number) => {
    if (risk >= 80) return { border: "border-red-500", bg: "bg-red-500/20", text: "text-red-400" };
    if (risk >= 60) return { border: "border-orange-500", bg: "bg-orange-500/20", text: "text-orange-400" };
    if (risk >= 40) return { border: "border-yellow-500", bg: "bg-yellow-500/20", text: "text-yellow-400" };
    return { border: "border-green-500", bg: "bg-green-500/20", text: "text-green-400" };
  };

  const getConnectionColor = (type: string) => {
    switch (type) {
      case "ownership":
        return "#3b82f6";
      case "director":
        return "#8b5cf6";
      case "family":
        return "#ec4899";
      case "transaction":
        return "#f97316";
      default:
        return "#64748b";
    }
  };

  return (
    <div className="relative w-full h-80 bg-slate-800/30 rounded-xl overflow-hidden">
      {/* Connection Lines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        {connections.map((conn, i) => {
          const from = entities.find((e) => e.id === conn.from);
          const to = entities.find((e) => e.id === conn.to);
          if (!from || !to) return null;
          return (
            <motion.line
              key={i}
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.6 }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              x1={`${from.x}%`}
              y1={`${from.y}%`}
              x2={`${to.x}%`}
              y2={`${to.y}%`}
              stroke={getConnectionColor(conn.type)}
              strokeWidth="2"
              strokeDasharray={conn.type === "transaction" ? "5,5" : "none"}
            />
          );
        })}
      </svg>

      {/* Entity Nodes */}
      {entities.map((entity, i) => {
        const Icon = getIcon(entity.type);
        const colors = getRiskColor(entity.risk);
        return (
          <motion.div
            key={entity.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: i * 0.1, type: "spring" }}
            className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group`}
            style={{ left: `${entity.x}%`, top: `${entity.y}%` }}
          >
            <div className={`w-12 h-12 rounded-full ${colors.bg} border-2 ${colors.border} flex items-center justify-center group-hover:scale-110 transition-transform`}>
              <Icon size={20} className={colors.text} />
            </div>
            <div className="absolute top-14 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
              <p className="text-xs text-white font-medium">{entity.name}</p>
              <p className="text-xs text-slate-500">Risk: {entity.risk}</p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}