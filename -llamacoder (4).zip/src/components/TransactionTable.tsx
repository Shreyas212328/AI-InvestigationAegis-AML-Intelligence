import { motion } from "framer-motion";
import { ArrowRight, AlertTriangle } from "lucide-react";
import { transactions } from "../data/mockData";

export default function TransactionTable() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden"
    >
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <h3 className="text-white font-semibold">Recent High-Risk Transactions</h3>
        <button className="text-blue-400 text-sm hover:text-blue-300 flex items-center gap-1">
          View All <ArrowRight size={14} />
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-800/50">
            <tr>
              <th className="text-left text-xs text-slate-400 font-medium px-4 py-3">ID</th>
              <th className="text-left text-xs text-slate-400 font-medium px-4 py-3">Customer</th>
              <th className="text-left text-xs text-slate-400 font-medium px-4 py-3">Country</th>
              <th className="text-left text-xs text-slate-400 font-medium px-4 py-3">Amount</th>
              <th className="text-left text-xs text-slate-400 font-medium px-4 py-3">Risk</th>
              <th className="text-left text-xs text-slate-400 font-medium px-4 py-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((tx, index) => (
              <motion.tr
                key={tx.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + index * 0.05 }}
                className="border-t border-slate-800 hover:bg-slate-800/50 transition-colors"
              >
                <td className="px-4 py-3 text-sm text-slate-300 font-mono">{tx.id}</td>
                <td className="px-4 py-3 text-sm text-white">{tx.customer}</td>
                <td className="px-4 py-3">
                  <span className="text-sm text-slate-300">{tx.country}</span>
                </td>
                <td className="px-4 py-3 text-sm text-white font-medium">
                  ${tx.amount.toLocaleString()}
                </td>
                <td className="px-4 py-3">
                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                    tx.risk === "Critical"
                      ? "bg-red-500/20 text-red-300"
                      : tx.risk === "High"
                      ? "bg-orange-500/20 text-orange-300"
                      : "bg-yellow-500/20 text-yellow-300"
                  }`}>
                    {tx.risk === "Critical" && <AlertTriangle size={12} />}
                    {tx.risk}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <button className="text-blue-400 text-sm hover:text-blue-300">
                    Review
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}