import { motion } from "framer-motion";
import { AlertTriangle, Shield, Newspaper, User, Globe } from "lucide-react";

interface IntelligenceCardProps {
  type: "sanctions" | "pep" | "adverse" | "criminal" | "country";
  title: string;
  description: string;
  severity: "low" | "medium" | "high" | "critical";
  details?: string[];
  timestamp?: string;
}

export default function IntelligenceCard({
  type,
  title,
  description,
  severity,
  details,
  timestamp,
}: IntelligenceCardProps) {
  const typeConfig = {
    sanctions: { icon: Shield, color: "red", label: "Sanctions" },
    pep: { icon: User, color: "purple", label: "PEP" },
    adverse: { icon: Newspaper, color: "orange", label: "Adverse Media" },
    criminal: { icon: AlertTriangle, color: "red", label: "Criminal" },
    country: { icon: Globe, color: "yellow", label: "Country Risk" },
  };

  const severityConfig = {
    low: { bg: "bg-green-500/10", border: "border-green-500/30", text: "text-green-400" },
    medium: { bg: "bg-yellow-500/10", border: "border-yellow-500/30", text: "text-yellow-400" },
    high: { bg: "bg-orange-500/10", border: "border-orange-500/30", text: "text-orange-400" },
    critical: { bg: "bg-red-500/10", border: "border-red-500/30", text: "text-red-400" },
  };

  const config = typeConfig[type];
  const severityColors = severityConfig[severity];
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className={`${severityColors.bg} border ${severityColors.border} rounded-xl p-4 cursor-pointer transition-all hover:shadow-lg`}
    >
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-lg ${severityColors.bg}`}>
          <Icon size={18} className={severityColors.text} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <span className={`text-xs font-medium ${severityColors.text} uppercase`}>
              {config.label}
            </span>
            {timestamp && (
              <span className="text-xs text-slate-500">{timestamp}</span>
            )}
          </div>
          <h4 className="text-white font-medium mb-1">{title}</h4>
          <p className="text-slate-400 text-sm mb-2">{description}</p>
          {details && details.length > 0 && (
            <ul className="space-y-1">
              {details.map((detail, i) => (
                <li key={i} className="text-xs text-slate-500 flex items-start gap-2">
                  <span className="text-slate-600">•</span>
                  {detail}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </motion.div>
  );
}