import { motion } from "framer-motion";
import { ExternalLink, AlertCircle } from "lucide-react";
import { sanctionsHits } from "../data/mockData";

export default function SanctionsTable() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.4 }}
      className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden"
    >
      <div className="px-6 py-4 bg-slate-800/50 border-b border-slate-800">
        <h3 className="text-white font-semibold">Recent Sanctions Hits</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-800">
              <th className="text-left px-6 py-3 text-slate-400 text-sm font-medium">Entity Name</th>
              <th className="text-left px-6 py-3 text-slate-400 text-sm font-medium">List</th>
              <th className="text-left px-6 py-3 text-slate-400 text-sm font-medium">Match Score</th>
              <th className="text-left px-6 py-3 text-slate-400 text-sm font-medium">Country</th>
              <th className="text-left px-6 py-3 text-slate-400 text-sm font-medium">Status</th>
              <th className="text-left px-6 py-3 text-slate-400 text-sm font-medium">Action</th>
            </tr>
          </thead>
          <tbody>
            {sanctionsHits.map((hit, index) => (
              <motion.tr 
                key={hit.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="border-b border-slate-800 hover:bg-slate-800/50 transition-colors"
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    {hit.isNew && (
                      <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 text-xs rounded font-medium">
                        NEW
                      </span>
                    )}
                    <span className="text-white font-medium">{hit.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    hit.list === 'OFAC' ? 'bg-red-500/20 text-red-400' :
                    hit.list === 'UN' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-purple-500/20 text-purple-400'
                  }`}>
                    {hit.list}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          hit.matchScore >= 90 ? 'bg-red-500' :
                          hit.matchScore >= 70 ? 'bg-amber-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${hit.matchScore}%` }}
                      />
                    </div>
                    <span className="text-white text-sm">{hit.matchScore}%</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-slate-300">{hit.country}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    hit.status === 'pending' ? 'bg-amber-500/20 text-amber-400' :
                    hit.status === 'reviewing' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    {hit.status.toUpperCase()}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="flex items-center gap-1 text-amber-500 hover:text-amber-400 transition-colors">
                    <span className="text-sm">View</span>
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}