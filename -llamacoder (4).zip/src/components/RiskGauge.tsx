import { motion } from "framer-motion";

interface RiskGaugeProps {
  score: number;
  label: string;
  size?: "sm" | "md" | "lg";
}

export default function RiskGauge({ score, label, size = "md" }: RiskGaugeProps) {
  const getColor = (s: number) => {
    if (s >= 80) return { stroke: "#ef4444", bg: "bg-red-500/20", text: "text-red-400" };
    if (s >= 60) return { stroke: "#f97316", bg: "bg-orange-500/20", text: "text-orange-400" };
    if (s >= 40) return { stroke: "#eab308", bg: "bg-yellow-500/20", text: "text-yellow-400" };
    return { stroke: "#22c55e", bg: "bg-green-500/20", text: "text-green-400" };
  };

  const getRiskLevel = (s: number) => {
    if (s >= 80) return "Critical";
    if (s >= 60) return "High";
    if (s >= 40) return "Medium";
    return "Low";
  };

  const colors = getColor(score);
  const radius = size === "lg" ? 60 : size === "md" ? 45 : 35;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <div className="relative">
        <svg width={radius * 2 + 20} height={radius * 2 + 20} className="transform -rotate-90">
          <circle
            cx={radius + 10}
            cy={radius + 10}
            r={radius}
            stroke="#1e293b"
            strokeWidth="8"
            fill="none"
          />
          <motion.circle
            cx={radius + 10}
            cy={radius + 10}
            r={radius}
            stroke={colors.stroke}
            strokeWidth="8"
            fill="none"
            strokeLinecap="round"
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.5, ease: "easeOut" }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className={`text-2xl font-bold ${colors.text}`}
            >
              {score}
            </motion.span>
          </div>
        </div>
      </div>
      <p className="text-slate-400 text-sm mt-2">{label}</p>
      <span className={`text-xs font-medium ${colors.text} mt-1`}>
        {getRiskLevel(score)}
      </span>
    </div>
  );
}